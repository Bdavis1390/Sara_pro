#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-$HOME/Sara_pro}"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO"
mkdir -p worldshepherd_sara/world_controller_static world_documents/inbox data
cp "$PATCH_DIR/world_controller_files/world_project_data.py" worldshepherd_sara/world_project_data.py
cp "$PATCH_DIR/world_controller_files/world_controller_static/index.html" worldshepherd_sara/world_controller_static/index.html
if [ -d "$PATCH_DIR/seed_documents" ]; then cp -n "$PATCH_DIR"/seed_documents/* world_documents/inbox/ 2>/dev/null || true; fi
python3 - <<'SERVPATCH'
from pathlib import Path
p=Path('worldshepherd_sara/server.py'); text=p.read_text(encoding='utf-8'); changed=False
imp='from worldshepherd_sara.world_project_data import router as world_project_data_router\n'; inc='app.include_router(world_project_data_router)\n'
if imp not in text:
    lines=text.splitlines(True); insert_at=0
    for i,l in enumerate(lines):
        if l.startswith('from ') or l.startswith('import '): insert_at=i+1
    lines.insert(insert_at,imp); text=''.join(lines); changed=True
if inc not in text:
    marker='app.include_router(world_controller_router)\n'; text=text.replace(marker,marker+inc) if marker in text else text+'\n# WORLD CONTROLLER real-time project data router\n'+inc; changed=True
if changed:
    p.with_suffix(p.suffix+'.bak_realtime_projects').write_text(p.read_text(encoding='utf-8'),encoding='utf-8'); p.write_text(text,encoding='utf-8'); print(f'Mounted realtime project data router in {p}')
else: print('Realtime project data router already mounted.')
SERVPATCH
if [ -f scripts/world_boot.sh ]; then
  cp scripts/world_boot.sh scripts/world_boot.sh.bak_realtime_projects 2>/dev/null || true
  python3 - <<'BOOTPATCH'
from pathlib import Path
p=Path('scripts/world_boot.sh'); text=p.read_text(encoding='utf-8')
block='''\n# WORLD CONTROLLER REALTIME PROJECTS PATCH — keep live dossier UI after base/full package install\nRT_ZIP="$(ls -t "$HOME"/Downloads/world_controller_realtime_projects_patch*.zip 2>/dev/null | head -n1 || true)"\nif [ -n "$RT_ZIP" ]; then\n  echo "[WORLD] Re-applying REALTIME PROJECT/DOCUMENT DOSSIER layer from: $RT_ZIP"\n  rm -rf /tmp/world_controller_realtime_projects_patch\n  mkdir -p /tmp/world_controller_realtime_projects_patch\n  unzip -o "$RT_ZIP" -d /tmp/world_controller_realtime_projects_patch >/dev/null\n  bash /tmp/world_controller_realtime_projects_patch/world_controller_realtime_projects_patch/scripts/install_world_controller_realtime_projects.sh "$REPO"\nfi\n'''
if 'WORLD CONTROLLER REALTIME PROJECTS PATCH' not in text:
    needle='echo "[WORLD] Compiling Python..."'; text=text.replace(needle,block+'\n'+needle) if needle in text else text+'\n'+block+'\n'; p.write_text(text,encoding='utf-8'); print('Patched scripts/world_boot.sh to preserve realtime dossier layer.')
else: print('scripts/world_boot.sh already preserves realtime dossier layer.')
BOOTPATCH
fi
python3 -m compileall worldshepherd_sara >/dev/null
cat > scripts/world_controller_realtime_smoke_test.sh <<'SMOKE'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ADMIN="$(grep '^SARA_ADMIN_TOKEN=' .env | cut -d= -f2-)"
BASE="http://127.0.0.1:9530"
echo "[1] realtime scan"; curl -fsS -H "X-SARA-ADMIN-TOKEN: $ADMIN" "$BASE/world/realtime/scan" | python3 -m json.tool >/dev/null
echo "[2] realtime dashboard dossier"; curl -fsS -H "X-SARA-ADMIN-TOKEN: $ADMIN" "$BASE/world/realtime/panel/dashboard" | python3 -m json.tool >/dev/null
echo "[3] realtime projects"; curl -fsS -H "X-SARA-ADMIN-TOKEN: $ADMIN" "$BASE/world/realtime/projects" | python3 -m json.tool >/dev/null
echo "[4] realtime documents"; curl -fsS -H "X-SARA-ADMIN-TOKEN: $ADMIN" "$BASE/world/realtime/documents?limit=20" | python3 -m json.tool >/dev/null
echo "WORLD CONTROLLER realtime project/document smoke test passed"
SMOKE
chmod +x scripts/world_controller_realtime_smoke_test.sh
echo "WORLD CONTROLLER realtime project/document dossier layer installed into $REPO"
echo "Seed documents copied into: $REPO/world_documents/inbox"
echo "Next: cd $REPO && ./scripts/world_boot.sh"
