#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$HOME/Sara_pro}"
PATCH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STATIC_SRC="$PATCH_ROOT/world_controller_files/world_controller_static/index.dossier.html"
STATIC_DST_DIR="$REPO/worldshepherd_sara/world_controller_static"
STATIC_DST="$STATIC_DST_DIR/index.html"
STATIC_CANONICAL="$STATIC_DST_DIR/index.dossier.html"

if [ ! -d "$REPO" ]; then
  echo "[WORLD-DOSSIER] ERROR: repo not found: $REPO" >&2
  exit 1
fi
if [ ! -f "$STATIC_SRC" ]; then
  echo "[WORLD-DOSSIER] ERROR: dossier UI source missing: $STATIC_SRC" >&2
  exit 1
fi

mkdir -p "$STATIC_DST_DIR" "$REPO/scripts"

if [ -f "$STATIC_DST" ]; then
  cp "$STATIC_DST" "$STATIC_DST.bak_dossier_$(date +%s)"
fi

cp "$STATIC_SRC" "$STATIC_CANONICAL"
cp "$STATIC_SRC" "$STATIC_DST"

cat > "$REPO/scripts/apply_world_controller_dossier_ui.sh" <<'APPLYEOF'
#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-$HOME/Sara_pro}"
CANONICAL="$REPO/worldshepherd_sara/world_controller_static/index.dossier.html"
TARGET="$REPO/worldshepherd_sara/world_controller_static/index.html"
if [ -f "$CANONICAL" ]; then
  cp "$CANONICAL" "$TARGET"
  echo "[WORLD-DOSSIER] Dossier UI applied."
else
  echo "[WORLD-DOSSIER] WARNING: canonical dossier UI missing: $CANONICAL" >&2
fi
APPLYEOF
chmod +x "$REPO/scripts/apply_world_controller_dossier_ui.sh"

cat > "$REPO/scripts/world_controller_dossier_smoke_test.sh" <<'SMOKEEOF'
#!/usr/bin/env bash
set -euo pipefail
cd "${1:-$HOME/Sara_pro}"
ADMIN="$(grep '^SARA_ADMIN_TOKEN=' .env | cut -d= -f2-)"
if [ -z "$ADMIN" ]; then
  echo "SARA_ADMIN_TOKEN missing in .env" >&2
  exit 1
fi
hdr=(-H "X-SARA-ADMIN-TOKEN: $ADMIN")

echo "[1] UI contains dossier renderer"
curl -fsS http://127.0.0.1:9530/world/ui | grep -q "Dossier Console"
curl -fsS http://127.0.0.1:9530/world/ui | grep -q "renderDossier"

echo "[2] Core dossier source endpoints"
for path in \
  /world/status \
  /world/dashboard \
  /world/watchers \
  /world/guardians \
  /world/oracle \
  /world/ark \
  /world/registry \
  /world/audit?limit=10 \
  /world/admin
  do
    echo "    GET $path"
    curl -fsS "${hdr[@]}" "http://127.0.0.1:9530$path" | python3 -m json.tool >/dev/null
  done

echo "[3] Command dossier source endpoints"
curl -fsS "${hdr[@]}" -H 'Content-Type: application/json' \
  -d '{"text":"SIMULATE REGISTRY PATCH SARA_CORE DRY_RUN ADMIN"}' \
  http://127.0.0.1:9530/world/command/parse | python3 -m json.tool >/dev/null
curl -fsS "${hdr[@]}" -H 'Content-Type: application/json' \
  -d '{"text":"SIMULATE REGISTRY PATCH SARA_CORE DRY_RUN ADMIN"}' \
  http://127.0.0.1:9530/world/oracle/simulate | python3 -m json.tool >/dev/null

echo "WORLD CONTROLLER dossier UI smoke test passed"
SMOKEEOF
chmod +x "$REPO/scripts/world_controller_dossier_smoke_test.sh"

# Make dossier mode survive world_boot.sh reinstalling full-controls package.
if [ -f "$REPO/scripts/world_boot.sh" ]; then
  if ! grep -q 'apply_world_controller_dossier_ui.sh' "$REPO/scripts/world_boot.sh"; then
    cp "$REPO/scripts/world_boot.sh" "$REPO/scripts/world_boot.sh.bak_dossier_$(date +%s)"
    python3 - "$REPO/scripts/world_boot.sh" <<'PYEOF'
from pathlib import Path
import sys
path = Path(sys.argv[1])
text = path.read_text()
insert = '''\nif [ -x "$REPO/scripts/apply_world_controller_dossier_ui.sh" ]; then\n  bash "$REPO/scripts/apply_world_controller_dossier_ui.sh" "$REPO"\nfi\n'''
needle = 'echo "[WORLD] Compiling Python..."'
if needle in text:
    text = text.replace(needle, insert + '\n' + needle, 1)
else:
    text += insert
path.write_text(text)
PYEOF
    chmod +x "$REPO/scripts/world_boot.sh"
    echo "[WORLD-DOSSIER] Patched world_boot.sh to reapply dossier UI after package installs."
  else
    echo "[WORLD-DOSSIER] world_boot.sh already reapplies dossier UI."
  fi
else
  echo "[WORLD-DOSSIER] WARNING: world_boot.sh not found; created UI patch only."
fi

python3 -m compileall "$REPO/worldshepherd_sara" >/dev/null || true

echo "[WORLD-DOSSIER] Dossier UI installed into $REPO"
echo "[WORLD-DOSSIER] Open: http://127.0.0.1:9530/world/ui"
echo "[WORLD-DOSSIER] Test: ./scripts/world_controller_dossier_smoke_test.sh"
