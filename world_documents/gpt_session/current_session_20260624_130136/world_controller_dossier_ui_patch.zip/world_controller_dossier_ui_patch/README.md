# WORLD CONTROLLER Dossier UI Patch

This patch replaces the WORLD CONTROLLER JSON-only output panel with a dossier-format console.

Each UI action renders:

- Operational Status
- Executive Summary when available
- Component Readout
- Registry / Watcher / Audit / Ark Evidence
- Guardian Gate / Risk Class
- Oracle Forecast
- Evidence Markers
- Recommended Next Actions
- Raw JSON, hidden behind a toggle

It does not loosen execution safety. RED/BLACK actions remain denied by the backend policy. The UI only changes the readout format.

## Install

```bash
cd ~/Sara_pro
PKG="$(ls -t ~/Downloads/world_controller_dossier_ui_patch*.zip 2>/dev/null | head -n1)"
rm -rf /tmp/world_controller_dossier_ui_patch
mkdir -p /tmp/world_controller_dossier_ui_patch
unzip -o "$PKG" -d /tmp/world_controller_dossier_ui_patch >/dev/null
bash /tmp/world_controller_dossier_ui_patch/world_controller_dossier_ui_patch/scripts/install_world_controller_dossier_ui.sh ~/Sara_pro
```

## Boot

```bash
cd ~/Sara_pro && ./scripts/world_boot.sh
```

## Test

From a second terminal while the server is running:

```bash
cd ~/Sara_pro && ./scripts/world_controller_dossier_smoke_test.sh
```
