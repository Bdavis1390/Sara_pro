#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$HOME/Sara_pro}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$PKG_DIR/world_controller_files"
DEST="$REPO/worldshepherd_sara"
TS="$(date +%Y%m%d_%H%M%S)"

echo "[WORLD-FULL] Repo: $REPO"

if [ ! -d "$REPO" ]; then
  echo "[WORLD-FULL] ERROR: repo not found: $REPO" >&2
  exit 1
fi

if [ ! -d "$DEST" ]; then
  echo "[WORLD-FULL] ERROR: worldshepherd_sara package not found: $DEST" >&2
  exit 1
fi

mkdir -p "$DEST/world_controller_static" "$REPO/scripts" "$REPO/data"

if [ -f "$DEST/world_controller.py" ]; then
  cp "$DEST/world_controller.py" "$DEST/world_controller.py.bak_full_controls_$TS"
fi
if [ -f "$DEST/world_controller_static/index.html" ]; then
  cp "$DEST/world_controller_static/index.html" "$DEST/world_controller_static/index.html.bak_full_controls_$TS"
fi

cp "$SRC/world_controller.py" "$DEST/world_controller.py"
cp "$SRC/world_controller_static/index.html" "$DEST/world_controller_static/index.html"
cp "$PKG_DIR/scripts/world_controller_full_smoke_test.sh" "$REPO/scripts/world_controller_full_smoke_test.sh"
chmod +x "$REPO/scripts/world_controller_full_smoke_test.sh"

# Ensure router mount exists in server.py if the original patch has not already done it.
PATCH="$REPO/scripts/patch_world_controller_mount.py"
if [ -f "$PATCH" ]; then
  python3 "$PATCH" || true
else
  if [ -f "$DEST/server.py" ] && ! grep -q "world_controller_router" "$DEST/server.py"; then
    cp "$DEST/server.py" "$DEST/server.py.bak_world_controller_mount_$TS"
    python3 - <<PY
from pathlib import Path
p = Path('$DEST/server.py')
s = p.read_text()
import_line = 'from worldshepherd_sara.world_controller import router as world_controller_router\n'
if import_line not in s:
    s = import_line + s
marker = 'app = FastAPI('
idx = s.find(marker)
if idx == -1:
    raise SystemExit('Could not find FastAPI app in server.py')
# Insert include_router after the app construction block by finding a later newline after first close paren.
insert = '\napp.include_router(world_controller_router)\n'
if insert.strip() not in s:
    pos = s.find('\n', idx)
    # Safer fallback: append at end. FastAPI app exists by then in most Sara_pro server layouts.
    s = s.rstrip() + insert
p.write_text(s)
PY
  fi
fi

cd "$REPO"
python3 -m compileall worldshepherd_sara >/dev/null

echo "[WORLD-FULL] Full controls installed."
echo "[WORLD-FULL] UI: http://127.0.0.1:9530/world/ui"
echo "[WORLD-FULL] Smoke test: ./scripts/world_controller_full_smoke_test.sh"
