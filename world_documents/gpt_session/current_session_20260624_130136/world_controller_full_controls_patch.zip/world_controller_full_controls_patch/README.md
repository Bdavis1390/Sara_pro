# WORLD CONTROLLER Full Controls Patch

This patch wires every visible WORLD CONTROLLER button/tab to a FastAPI backend endpoint.

## Install

```bash
cd ~/Sara_pro
PKG=/tmp/world_controller_full_controls_patch/world_controller_full_controls_patch
bash "$PKG/scripts/install_world_controller_full_controls.sh" ~/Sara_pro
```

## Boot

```bash
cd ~/Sara_pro && ./scripts/world_boot.sh
```

## Smoke test from a second terminal

```bash
cd ~/Sara_pro && ./scripts/world_controller_full_smoke_test.sh
```

## Routes added/verified

- `/world/ui`
- `/world/status`
- `/world/dashboard`
- `/world/watchers`
- `/world/guardians`
- `/world/guardians/classify`
- `/world/oracle`
- `/world/oracle/simulate`
- `/world/ark`
- `/world/ark/snapshot`
- `/world/registry`
- `/world/registry/patch`
- `/world/audit`
- `/world/admin`
- `/world/command/parse`
- `/world/command/simulate`
- `/world/command/execute`

Execution remains safe-local by default. GREEN/BLUE require confirmation, AMBER requires `WORLD_ALLOW_AMBER_EXECUTE=1`, and RED/BLACK are denied by default.
