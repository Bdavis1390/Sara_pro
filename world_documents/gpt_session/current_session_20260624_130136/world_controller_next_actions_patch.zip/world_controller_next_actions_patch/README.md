# WORLD CONTROLLER Next Actions / Preflight Patch

This patch turns the UI Recommended Next Actions into clickable, auditable workflow steps:

1. Watchers heartbeat inspection
2. Guardian command classification
3. Oracle dry-run forecast
4. Ark pre-change snapshot
5. Full preflight chain
6. Preflight evidence dossier

All actions are local-first and simulate-first. Completing preflight does not bypass Guardian policy.
