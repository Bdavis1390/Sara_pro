#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$HOME/Sara_pro}"
PATCH_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ ! -d "$REPO" ]; then
  echo "ERROR: repo not found: $REPO" >&2
  exit 1
fi
if [ ! -d "$REPO/worldshepherd_sara" ]; then
  echo "ERROR: $REPO/worldshepherd_sara not found" >&2
  exit 1
fi

mkdir -p "$REPO/worldshepherd_sara/world_controller_static"

if [ -f "$REPO/worldshepherd_sara/world_controller.py" ]; then
  cp "$REPO/worldshepherd_sara/world_controller.py" "$REPO/worldshepherd_sara/world_controller.py.bak_next_actions_$(date +%s)"
fi

cp "$PATCH_ROOT/world_controller_files/world_controller.py" "$REPO/worldshepherd_sara/world_controller.py"
cp "$PATCH_ROOT/world_controller_files/world_controller_static/index.html" "$REPO/worldshepherd_sara/world_controller_static/index.html"

# Ensure FastAPI router is mounted.
if [ -f "$REPO/scripts/patch_world_controller_mount.py" ]; then
  python3 "$REPO/scripts/patch_world_controller_mount.py" >/dev/null || true
else
  cat > "$REPO/scripts/patch_world_controller_mount.py" <<'PY'
from pathlib import Path
root = Path.cwd()
candidates = list((root / "worldshepherd_sara").glob("*.py"))
import_line = "from worldshepherd_sara.world_controller import router as world_controller_router\n"
include_line = "app.include_router(world_controller_router)\n"
for path in candidates:
    text = path.read_text(encoding="utf-8")
    if "FastAPI(" in text and "app =" in text:
        changed = False
        if import_line.strip() not in text:
            text = import_line + text
            changed = True
        if include_line.strip() not in text:
            lines = text.splitlines(True)
            insert_at = len(lines)
            for i, line in enumerate(lines):
                if "app =" in line and "FastAPI(" in line:
                    insert_at = i + 1
                    break
            lines.insert(insert_at, include_line)
            text = "".join(lines)
            changed = True
        if changed:
            path.write_text(text, encoding="utf-8")
            print(f"Mounted WORLD CONTROLLER in {path}")
        else:
            print(f"WORLD CONTROLLER already mounted in {path}")
        raise SystemExit(0)
print("WARNING: could not find FastAPI app for auto-mount. Mount manually if /world/ui 404s.")
PY
  python3 "$REPO/scripts/patch_world_controller_mount.py" >/dev/null || true
fi

# Smoke test for next-action / preflight workflow.
cat > "$REPO/scripts/world_controller_next_actions_smoke_test.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ADMIN="$(grep '^SARA_ADMIN_TOKEN=' .env | cut -d= -f2-)"
BASE="http://127.0.0.1:9530"
HDR=(-H "X-SARA-ADMIN-TOKEN: $ADMIN" -H "Content-Type: application/json")
BODY='{"text":"SIMULATE REGISTRY PATCH SARA_CORE DRY_RUN ADMIN"}'

echo "[1] GET /world/preflight"
curl -fsS "${HDR[@]}" "$BASE/world/preflight" | python3 -m json.tool >/dev/null

echo "[2] POST /world/preflight/watchers"
curl -fsS -X POST "${HDR[@]}" "$BASE/world/preflight/watchers" | python3 -m json.tool >/dev/null

echo "[3] POST /world/preflight/guardians"
curl -fsS -X POST "${HDR[@]}" --data "$BODY" "$BASE/world/preflight/guardians" | python3 -m json.tool >/dev/null

echo "[4] POST /world/preflight/oracle"
curl -fsS -X POST "${HDR[@]}" --data "$BODY" "$BASE/world/preflight/oracle" | python3 -m json.tool >/dev/null

echo "[5] POST /world/preflight/ark"
curl -fsS -X POST "${HDR[@]}" "$BASE/world/preflight/ark" | python3 -m json.tool >/dev/null

echo "[6] POST /world/preflight/run"
curl -fsS -X POST "${HDR[@]}" --data "$BODY" "$BASE/world/preflight/run" | python3 -m json.tool >/dev/null

echo "[7] GET /world/evidence/preflight"
curl -fsS "${HDR[@]}" "$BASE/world/evidence/preflight" | python3 -m json.tool >/dev/null

echo "WORLD CONTROLLER next-actions preflight smoke test passed"
SH
chmod +x "$REPO/scripts/world_controller_next_actions_smoke_test.sh"

# Replace boot script so the next-actions package is not overwritten by older packages.
cat > "$REPO/scripts/world_boot.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$HOME/Sara_pro}"
NEXT_ZIP="$(ls -t "$HOME"/Downloads/world_controller_next_actions_patch*.zip 2>/dev/null | head -n1 || true)"
EVIDENCE_ZIP="$(ls -t "$HOME"/Downloads/world_controller_evidence_links_patch*.zip 2>/dev/null | head -n1 || true)"
DOSSIER_ZIP="$(ls -t "$HOME"/Downloads/world_controller_dossier_ui_patch*.zip 2>/dev/null | head -n1 || true)"
FULL_ZIP="$(ls -t "$HOME"/Downloads/world_controller_full_controls_patch*.zip 2>/dev/null | head -n1 || true)"
BASE_ZIP="$(ls -t "$HOME"/Downloads/world_controller_build_package*.zip 2>/dev/null | head -n1 || true)"

echo "[WORLD] Repo: $REPO"
cd "$REPO"

install_zip() {
  local zip="$1" tmp="$2" inner="$3" script="$4" label="$5"
  echo "[WORLD] Installing $label from: $zip"
  rm -rf "$tmp"
  mkdir -p "$tmp"
  unzip -o "$zip" -d "$tmp" >/dev/null
  bash "$tmp/$inner/scripts/$script" "$REPO"
}

if [ -n "$NEXT_ZIP" ]; then
  install_zip "$NEXT_ZIP" /tmp/world_controller_next_actions_patch world_controller_next_actions_patch install_world_controller_next_actions.sh "NEXT-ACTIONS CONTROLS"
elif grep -q '@router.get("/preflight")' "$REPO/worldshepherd_sara/world_controller.py" 2>/dev/null; then
  echo "[WORLD] Next-actions controls already present."
elif [ -n "$EVIDENCE_ZIP" ]; then
  install_zip "$EVIDENCE_ZIP" /tmp/world_controller_evidence_links_patch world_controller_evidence_links_patch install_world_controller_evidence_links.sh "EVIDENCE LINKS"
elif [ -n "$DOSSIER_ZIP" ]; then
  install_zip "$DOSSIER_ZIP" /tmp/world_controller_dossier_ui_patch world_controller_dossier_ui_patch install_world_controller_dossier_ui.sh "DOSSIER UI"
elif [ -n "$FULL_ZIP" ]; then
  install_zip "$FULL_ZIP" /tmp/world_controller_full_controls_patch world_controller_full_controls_patch install_world_controller_full_controls.sh "FULL CONTROLS"
elif [ -n "$BASE_ZIP" ]; then
  install_zip "$BASE_ZIP" /tmp/world_controller_build world_controller_build_package install_world_controller.sh "BASE CONTROLS"
else
  echo "[WORLD] WARNING: no WORLD CONTROLLER package zip found in ~/Downloads."
  echo "[WORLD] Continuing with existing repo files."
fi

if [ ! -f "$REPO/.env" ] && [ -f "$REPO/.env.example" ]; then
  cp "$REPO/.env.example" "$REPO/.env"
elif [ ! -f "$REPO/.env" ]; then
  touch "$REPO/.env"
fi
if ! grep -q '^SARA_ADMIN_TOKEN=' "$REPO/.env"; then
  echo "SARA_ADMIN_TOKEN=change-me-admin-token" >> "$REPO/.env"
fi

echo "[WORLD] Verifying next-actions route..."
grep -n '@router.get("/preflight")' "$REPO/worldshepherd_sara/world_controller.py" >/dev/null || {
  echo "[WORLD] WARNING: /world/preflight route missing. UI may be older than next-actions build."
}

echo "[WORLD] Compiling Python..."
python3 -m compileall worldshepherd_sara >/dev/null

echo
echo "[WORLD] Boot targets:"
echo "  Legacy UI: http://127.0.0.1:9530/ui"
echo "  WORLD UI:  http://127.0.0.1:9530/world/ui"
echo

if [ -x "$REPO/scripts/start_interface.sh" ]; then
  exec "$REPO/scripts/start_interface.sh"
else
  echo "[WORLD] ERROR: scripts/start_interface.sh not found or not executable."
  exit 1
fi
SH
chmod +x "$REPO/scripts/world_boot.sh"

python3 -m compileall "$REPO/worldshepherd_sara" >/dev/null || true

echo "WORLD CONTROLLER next-actions/preflight controls installed into $REPO"
echo "Next: cd $REPO && ./scripts/world_boot.sh"
