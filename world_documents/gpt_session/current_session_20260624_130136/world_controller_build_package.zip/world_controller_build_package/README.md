# WORLD CONTROLLER Build Package

This package adds the initial WORLD CONTROLLER interface to the existing `Sara_pro` / `worldshepherd_sara` repo.

Run from `~/Sara_pro`:

```bash
bash /path/to/world_controller_build_package/scripts/install_world_controller.sh ~/Sara_pro
python scripts/patch_world_controller_mount.py
python -m compileall worldshepherd_sara
./scripts/start_interface.sh
./scripts/world_controller_smoke_test.sh
```

Open:

```text
http://127.0.0.1:9530/world/ui
```

Use `SARA_ADMIN_TOKEN` from your `.env`.
