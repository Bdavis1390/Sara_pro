#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(pwd)}"
cd "$ROOT"

if [ ! -d "worldshepherd_sara" ]; then
  echo "ERROR: worldshepherd_sara/ not found. Run this from ~/Sara_pro or pass the repo path:" >&2
  echo "  ./scripts/install_world_controller.sh ~/Sara_pro" >&2
  exit 1
fi

mkdir -p worldshepherd_sara/world_controller_static scripts docs data

cat > worldshepherd_sara/world_controller.py <<'PY'
"""
WORLD CONTROLLER router for Worldshepherd SARA / SSPADAWANZZ.

Local-first, simulate-first command interface.
Mount into your existing FastAPI app with:

    from worldshepherd_sara.world_controller import router as world_controller_router
    app.include_router(world_controller_router)

Environment:
    SARA_ADMIN_TOKEN=...
    SARA_RELAY_TOKEN=...
    WORLD_ALLOW_AMBER_EXECUTE=0|1
    WORLD_DATA_DIR=data
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

try:
    from fastapi import APIRouter, Header, HTTPException
    from fastapi.responses import HTMLResponse, JSONResponse
    from pydantic import BaseModel, Field
except Exception as exc:  # pragma: no cover
    raise RuntimeError(
        "WORLD CONTROLLER requires FastAPI and Pydantic in the Sara_pro environment."
    ) from exc

router = APIRouter(prefix="/world", tags=["WORLD CONTROLLER"])

RiskClass = Literal["GREEN", "BLUE", "AMBER", "RED", "BLACK"]
Intent = Literal[
    "OBSERVE",
    "SIMULATE",
    "CONFIGURE",
    "RELAY",
    "PATCH",
    "DEPLOY",
    "ROLLBACK",
    "ARCHIVE",
    "EXECUTE",
]
Mode = Literal["DRY_RUN", "EXECUTE", "QUEUE", "REQUIRE_APPROVAL"]


class WorldCommand(BaseModel):
    intent: Intent = Field(..., description="Command intent")
    target: str = Field(..., min_length=1, description="Target node/service/module")
    action: str = Field(..., min_length=1, description="Action verb")
    scope: str = Field("local", description="Scope of action")
    mode: Mode = Field("DRY_RUN", description="Execution mode")
    reason: str = Field("", description="Human reason / mission note")
    payload: Dict[str, Any] = Field(default_factory=dict)
    execute_confirm: bool = Field(False, description="Second-key confirmation for execution")


class NaturalCommand(BaseModel):
    text: str = Field(..., min_length=1)


@dataclass
class GateResult:
    guardian_class: RiskClass
    guardian_allowed: bool
    oracle_result: str
    sentinel_result: str
    ark_snapshot_id: str
    messages: List[str] = field(default_factory=list)


def _dump_model(model: BaseModel) -> Dict[str, Any]:
    if hasattr(model, "model_dump"):
        return model.model_dump()  # pydantic v2
    return model.dict()  # pydantic v1


def _data_dir() -> Path:
    root = Path(os.getenv("WORLD_DATA_DIR", "data"))
    root.mkdir(parents=True, exist_ok=True)
    return root


def _audit_path() -> Path:
    return _data_dir() / "world_controller_audit.jsonl"


def _registry_path() -> Path:
    return _data_dir() / "world_controller_registry.json"


def _now() -> float:
    return time.time()


def _token_from_header(authorization: Optional[str], x_sara_admin_token: Optional[str]) -> Optional[str]:
    if x_sara_admin_token:
        return x_sara_admin_token.strip()
    if authorization and authorization.lower().startswith("bearer "):
        return authorization.split(" ", 1)[1].strip()
    return None


def _require_admin(authorization: Optional[str], x_sara_admin_token: Optional[str]) -> str:
    expected = os.getenv("SARA_ADMIN_TOKEN", "")
    supplied = _token_from_header(authorization, x_sara_admin_token)
    if not expected:
        raise HTTPException(status_code=500, detail="SARA_ADMIN_TOKEN is not set")
    if supplied != expected:
        raise HTTPException(status_code=403, detail="WORLD CONTROLLER admin token required")
    return "SSPADAWANZZ_ADMIN"


def _append_audit(record: Dict[str, Any]) -> Dict[str, Any]:
    record = {"ts": _now(), **record}
    with _audit_path().open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, sort_keys=True) + "\n")
    return record


def _read_audit(limit: int = 50) -> List[Dict[str, Any]]:
    path = _audit_path()
    if not path.exists():
        return []
    lines = path.read_text(encoding="utf-8").splitlines()[-max(1, min(limit, 500)) :]
    out: List[Dict[str, Any]] = []
    for line in lines:
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return list(reversed(out))


def _default_registry() -> Dict[str, Any]:
    return {
        "SARA_CORE": {"role": "core", "status": "online", "capabilities": ["relay", "audit", "registry"], "guardian_policy": "AMBER"},
        "SSPADAWANZZ": {"role": "admin_operator", "status": "online", "capabilities": ["observe", "simulate", "relay", "audit_read", "registry_patch"], "guardian_policy": "AMBER"},
        "WATCHER_GRID": {"role": "telemetry", "status": "standby", "capabilities": ["observe", "health", "heartbeat"], "guardian_policy": "GREEN"},
        "GUARDIAN_POLICY": {"role": "safety_gate", "status": "enforced", "capabilities": ["classify", "deny", "require_approval"], "guardian_policy": "RED"},
        "ORACLE_ENGINE": {"role": "simulator", "status": "simulate_first", "capabilities": ["dry_run", "impact_estimate", "rollback_estimate"], "guardian_policy": "BLUE"},
        "ARK_STORE": {"role": "continuity", "status": "ready", "capabilities": ["snapshot", "restore_point", "checksum"], "guardian_policy": "AMBER"},
    }


def _load_registry() -> Dict[str, Any]:
    path = _registry_path()
    if not path.exists():
        registry = _default_registry()
        path.write_text(json.dumps(registry, indent=2, sort_keys=True), encoding="utf-8")
        return registry
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        path.replace(path.with_suffix(".corrupt.json"))
        registry = _default_registry()
        path.write_text(json.dumps(registry, indent=2, sort_keys=True), encoding="utf-8")
        return registry


def _risk_for(cmd: WorldCommand) -> RiskClass:
    target = cmd.target.upper()
    action = cmd.action.lower()
    intent = cmd.intent.upper()
    text = f"{target} {action} {cmd.scope}".lower()
    if any(term in text for term in ["weapon", "harm", "exfiltrate", "steal", "bypass", "disable_audit", "delete_audit"]):
        return "BLACK"
    if any(term in text for term in ["rf", "metasurface", "actuator", "thermal", "voltage", "phase_shifter", "material_state"]):
        return "RED"
    if intent in {"DEPLOY", "EXECUTE"}:
        return "RED"
    if intent in {"PATCH", "RELAY", "ROLLBACK"}:
        return "AMBER"
    if intent in {"CONFIGURE", "ARCHIVE"}:
        return "BLUE"
    return "GREEN"


def _oracle(cmd: WorldCommand, risk: RiskClass) -> str:
    if risk == "BLACK":
        return "unsafe_or_forbidden_path_detected"
    if risk == "RED":
        return "requires_offline_review_or_hardware_safety_case"
    if risk == "AMBER":
        return "reversible_if_ark_snapshot_exists_admin_approval_required"
    if risk == "BLUE":
        return "local_reversible_change_expected"
    return "read_or_simulation_only_low_risk"


def _gate(cmd: WorldCommand) -> GateResult:
    risk = _risk_for(cmd)
    messages: List[str] = []
    allow_amber = os.getenv("WORLD_ALLOW_AMBER_EXECUTE", "0") == "1"
    if cmd.mode != "EXECUTE":
        allowed = risk != "BLACK"
        messages.append("dry_run_or_queue_mode_no_real_action_taken")
    elif risk in {"GREEN", "BLUE"}:
        allowed = cmd.execute_confirm
        if not cmd.execute_confirm:
            messages.append("execute_confirm_required")
    elif risk == "AMBER":
        allowed = allow_amber and cmd.execute_confirm
        messages.append("amber_execution_requires_WORLD_ALLOW_AMBER_EXECUTE=1_and_execute_confirm=true")
    else:
        allowed = False
        messages.append("red_or_black_execution_denied_by_default")
    return GateResult(
        guardian_class=risk,
        guardian_allowed=allowed,
        oracle_result=_oracle(cmd, risk),
        sentinel_result="identity_and_doctrine_gate_checked",
        ark_snapshot_id=f"ARK-RP-{int(_now())}",
        messages=messages,
    )


def _parse_natural(text: str) -> WorldCommand:
    raw = text.strip()
    upper = raw.upper()
    intent: Intent = "OBSERVE"
    mode: Mode = "DRY_RUN"
    for candidate in ["SIMULATE", "CONFIGURE", "RELAY", "PATCH", "DEPLOY", "ROLLBACK", "ARCHIVE", "EXECUTE", "OBSERVE"]:
        if upper.startswith(candidate):
            intent = candidate  # type: ignore[assignment]
            break
    if " EXECUTE" in upper or upper.startswith("EXECUTE"):
        mode = "EXECUTE"
    elif "QUEUE" in upper:
        mode = "QUEUE"
    elif "APPROVAL" in upper:
        mode = "REQUIRE_APPROVAL"
    known_targets = ["SARA_CORE", "SSPADAWANZZ", "WATCHER_GRID", "GUARDIAN_POLICY", "ORACLE_ENGINE", "ARK_STORE", "REGISTRY"]
    target = "SARA_CORE"
    for candidate in known_targets:
        if candidate in upper:
            target = candidate
            break
    words = raw.split()
    action = "review" if len(words) < 2 else words[1].lower().replace("/", "_")[:48]
    return WorldCommand(intent=intent, target=target, action=action, scope="local", mode=mode, reason=raw)


@router.get("/ui", response_class=HTMLResponse)
def world_ui() -> HTMLResponse:
    html_path = Path(__file__).with_name("world_controller_static") / "index.html"
    if html_path.exists():
        return HTMLResponse(html_path.read_text(encoding="utf-8"))
    return HTMLResponse("<h1>WORLD CONTROLLER</h1><p>Static UI missing, API is mounted.</p>")


@router.get("/status")
def world_status(authorization: Optional[str] = Header(default=None), x_sara_admin_token: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    actor = _require_admin(authorization, x_sara_admin_token)
    registry = _load_registry()
    record = _append_audit({"actor": actor, "event": "world_status_read", "payload": {}})
    return {"ok": True, "service": "WORLD CONTROLLER", "mode": "simulate_first", "actor": actor, "registry_nodes": len(registry), "routes": ["/world/ui", "/world/status", "/world/registry", "/world/command/simulate", "/world/command/execute", "/world/audit"], "audit_recorded": record["ts"]}


@router.get("/registry")
def world_registry(authorization: Optional[str] = Header(default=None), x_sara_admin_token: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    actor = _require_admin(authorization, x_sara_admin_token)
    registry = _load_registry()
    _append_audit({"actor": actor, "event": "world_registry_read", "payload": {"nodes": list(registry.keys())}})
    return {"ok": True, "registry": registry}


@router.post("/command/parse")
def world_command_parse(body: NaturalCommand, authorization: Optional[str] = Header(default=None), x_sara_admin_token: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    actor = _require_admin(authorization, x_sara_admin_token)
    cmd = _parse_natural(body.text)
    gate = _gate(cmd)
    _append_audit({"actor": actor, "event": "world_command_parse", "payload": {"text": body.text, "command": _dump_model(cmd), "gate": asdict(gate)}})
    return {"ok": True, "command": _dump_model(cmd), "gate": asdict(gate)}


@router.post("/command/simulate")
def world_command_simulate(cmd: WorldCommand, authorization: Optional[str] = Header(default=None), x_sara_admin_token: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    actor = _require_admin(authorization, x_sara_admin_token)
    cmd.mode = "DRY_RUN"
    gate = _gate(cmd)
    _append_audit({"actor": actor, "event": "world_command_simulate", "payload": {"command": _dump_model(cmd), "gate": asdict(gate)}})
    return {"ok": gate.guardian_class != "BLACK", "executed": False, "command": _dump_model(cmd), "gate": asdict(gate)}


@router.post("/command/execute")
def world_command_execute(cmd: WorldCommand, authorization: Optional[str] = Header(default=None), x_sara_admin_token: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    actor = _require_admin(authorization, x_sara_admin_token)
    cmd.mode = "EXECUTE"
    gate = _gate(cmd)
    event = "world_command_execute_allowed" if gate.guardian_allowed else "world_command_execute_denied"
    _append_audit({"actor": actor, "event": event, "payload": {"command": _dump_model(cmd), "gate": asdict(gate)}})
    if not gate.guardian_allowed:
        return JSONResponse(status_code=403, content={"ok": False, "executed": False, "command": _dump_model(cmd), "gate": asdict(gate)})
    return {"ok": True, "executed": True, "note": "safe_local_execution_recorded_no_external_side_effect", "command": _dump_model(cmd), "gate": asdict(gate)}


@router.get("/audit")
def world_audit(limit: int = 50, authorization: Optional[str] = Header(default=None), x_sara_admin_token: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    actor = _require_admin(authorization, x_sara_admin_token)
    rows = _read_audit(limit=limit)
    _append_audit({"actor": actor, "event": "world_audit_read", "payload": {"limit": limit, "returned": len(rows)}})
    return {"ok": True, "records": rows}
PY

cat > worldshepherd_sara/world_controller_static/index.html <<'HTML'
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>WORLD CONTROLLER</title>
  <style>
    :root { color-scheme: dark; font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
    body { margin: 0; background: #090b10; color: #e8eef8; }
    header { padding: 16px 22px; border-bottom: 1px solid #263244; display: flex; justify-content: space-between; align-items: center; }
    h1 { margin: 0; font-size: 20px; letter-spacing: .08em; }
    .badge { border: 1px solid #40506a; padding: 6px 10px; border-radius: 999px; color: #b9c8de; }
    main { display: grid; grid-template-columns: 240px 1fr 360px; min-height: calc(100vh - 65px); }
    nav, aside { border-right: 1px solid #263244; padding: 16px; background: #0d1119; }
    aside { border-right: 0; border-left: 1px solid #263244; }
    section { padding: 18px; }
    button, input, textarea { background: #111827; color: #e8eef8; border: 1px solid #344158; border-radius: 8px; padding: 10px; }
    button { cursor: pointer; margin: 4px 4px 4px 0; }
    button:hover { background: #182235; }
    textarea { width: 100%; min-height: 110px; box-sizing: border-box; }
    input { width: 100%; box-sizing: border-box; margin: 6px 0 14px; }
    pre { background: #05070b; border: 1px solid #263244; border-radius: 10px; padding: 12px; overflow: auto; max-height: 420px; }
    .card { border: 1px solid #263244; border-radius: 14px; padding: 14px; margin-bottom: 14px; background: #0b0f17; }
    .rail-item { padding: 10px; border: 1px solid #263244; border-radius: 10px; margin-bottom: 8px; color: #c9d6e8; }
    label { color: #aab8cd; font-size: 13px; }
  </style>
</head>
<body>
  <header><h1>WORLD CONTROLLER</h1><span class="badge">SIMULATE-FIRST / LOCAL ADMIN</span></header>
  <main>
    <nav>
      <div class="rail-item">Dashboard</div><div class="rail-item">Watchers</div><div class="rail-item">Guardians</div><div class="rail-item">Oracle</div><div class="rail-item">Ark</div><div class="rail-item">Registry</div><div class="rail-item">Audit</div>
    </nav>
    <section>
      <div class="card"><label>Admin Token</label><input id="token" type="password" placeholder="Paste SARA_ADMIN_TOKEN here" /><button onclick="statusCheck()">Status</button><button onclick="loadRegistry()">Registry</button><button onclick="loadAudit()">Audit</button></div>
      <div class="card"><h2>Command Builder</h2><textarea id="cmdText">SIMULATE REGISTRY PATCH SARA_CORE DRY_RUN ADMIN</textarea><br /><button onclick="parseCommand()">Parse</button><button onclick="simulateStructured()">Simulate Structured</button><button onclick="executeBlue()">Execute Safe BLUE Test</button></div>
      <div class="card"><h2>Output</h2><pre id="out">Ready.</pre></div>
    </section>
    <aside><div class="card"><h3>Guardian</h3><p>GREEN/BLUE may execute with confirmation. AMBER requires explicit env unlock. RED/BLACK deny by default.</p></div><div class="card"><h3>Oracle</h3><p>Every command can be simulated before execution.</p></div><div class="card"><h3>Ark</h3><p>Every command receives an Ark restore-point identifier.</p></div></aside>
  </main>
<script>
const out = document.getElementById('out');
function token() { return document.getElementById('token').value.trim(); }
async function api(path, opts={}) { opts.headers = Object.assign({'Content-Type': 'application/json', 'X-SARA-ADMIN-TOKEN': token()}, opts.headers || {}); const res = await fetch(path, opts); const text = await res.text(); try { return JSON.parse(text); } catch { return {raw: text, status: res.status}; } }
function show(x) { out.textContent = JSON.stringify(x, null, 2); }
async function statusCheck(){ show(await api('/world/status')); }
async function loadRegistry(){ show(await api('/world/registry')); }
async function loadAudit(){ show(await api('/world/audit?limit=25')); }
async function parseCommand(){ show(await api('/world/command/parse', {method:'POST', body: JSON.stringify({text: document.getElementById('cmdText').value})})); }
async function simulateStructured(){ const body = {intent:'PATCH', target:'REGISTRY', action:'patch', scope:'SARA_CORE', mode:'DRY_RUN', reason:document.getElementById('cmdText').value, payload:{demo:true}}; show(await api('/world/command/simulate', {method:'POST', body: JSON.stringify(body)})); }
async function executeBlue(){ const body = {intent:'CONFIGURE', target:'ORACLE_ENGINE', action:'set_mode', scope:'local', mode:'EXECUTE', reason:'safe local execution smoke test', payload:{mode:'simulate_first'}, execute_confirm:true}; show(await api('/world/command/execute', {method:'POST', body: JSON.stringify(body)})); }
</script>
</body>
</html>
HTML

cat > scripts/patch_world_controller_mount.py <<'PY'
#!/usr/bin/env python3
"""Best-effort FastAPI mount patcher for WORLD CONTROLLER."""
from pathlib import Path

ROOT = Path.cwd()
IMPORT_LINE = "from worldshepherd_sara.world_controller import router as world_controller_router\n"
INCLUDE_LINE = "app.include_router(world_controller_router)\n"

candidates = []
for path in (ROOT / "worldshepherd_sara").rglob("*.py"):
    text = path.read_text(encoding="utf-8", errors="ignore")
    if "FastAPI(" in text and "app" in text:
        candidates.append(path)

if not candidates:
    print("ERROR: Could not find a FastAPI app file under worldshepherd_sara/.")
    print("Manually add:")
    print(IMPORT_LINE.rstrip())
    print(INCLUDE_LINE.rstrip())
    raise SystemExit(1)

path = candidates[0]
text = path.read_text(encoding="utf-8")
if "world_controller_router" in text:
    print(f"Already mounted or imported in {path}")
    raise SystemExit(0)

lines = text.splitlines(keepends=True)
insert_import_at = 0
for idx, line in enumerate(lines):
    if line.startswith("from ") or line.startswith("import "):
        insert_import_at = idx + 1
lines.insert(insert_import_at, IMPORT_LINE)
text = "".join(lines)

# Place include after the first app = FastAPI(...) line if it is one-line; otherwise append near end.
lines = text.splitlines(keepends=True)
inserted = False
for idx, line in enumerate(lines):
    if "FastAPI(" in line and "=" in line and line.rstrip().endswith(")"):
        lines.insert(idx + 1, INCLUDE_LINE)
        inserted = True
        break
if not inserted:
    lines.append("\n# WORLD CONTROLLER mount\n")
    lines.append(INCLUDE_LINE)

backup = path.with_suffix(path.suffix + ".bak_world_controller")
backup.write_text(path.read_text(encoding="utf-8"), encoding="utf-8")
path.write_text("".join(lines), encoding="utf-8")
print(f"Mounted WORLD CONTROLLER in {path}")
print(f"Backup written to {backup}")
PY
chmod +x scripts/patch_world_controller_mount.py

cat > scripts/world_controller_smoke_test.sh <<'SH2'
#!/usr/bin/env bash
set -euo pipefail
BASE="${BASE:-http://127.0.0.1:9530}"
TOKEN="${SARA_ADMIN_TOKEN:-}"
if [ -f .env ] && [ -z "$TOKEN" ]; then
  TOKEN="$(grep -E '^SARA_ADMIN_TOKEN=' .env | tail -1 | cut -d= -f2- | tr -d '"' || true)"
fi
if [ -z "$TOKEN" ]; then
  echo "ERROR: SARA_ADMIN_TOKEN not found in environment or .env" >&2
  exit 1
fi

echo "[1] WORLD status"
curl -fsS -H "X-SARA-ADMIN-TOKEN: $TOKEN" "$BASE/world/status" | python -m json.tool

echo "[2] WORLD parse"
curl -fsS -X POST -H "Content-Type: application/json" -H "X-SARA-ADMIN-TOKEN: $TOKEN" \
  -d '{"text":"SIMULATE REGISTRY PATCH SARA_CORE DRY_RUN ADMIN"}' \
  "$BASE/world/command/parse" | python -m json.tool

echo "[3] WORLD simulate structured"
curl -fsS -X POST -H "Content-Type: application/json" -H "X-SARA-ADMIN-TOKEN: $TOKEN" \
  -d '{"intent":"PATCH","target":"REGISTRY","action":"patch","scope":"SARA_CORE","mode":"DRY_RUN","reason":"smoke test","payload":{"demo":true}}' \
  "$BASE/world/command/simulate" | python -m json.tool

echo "[4] WORLD audit"
curl -fsS -H "X-SARA-ADMIN-TOKEN: $TOKEN" "$BASE/world/audit?limit=10" | python -m json.tool

echo "WORLD CONTROLLER smoke test passed"
SH2
chmod +x scripts/world_controller_smoke_test.sh

cat >> .env.example <<'ENV_APPEND'

# WORLD CONTROLLER
WORLD_DATA_DIR=data
WORLD_ALLOW_AMBER_EXECUTE=0
ENV_APPEND

cat > docs/WORLD_CONTROLLER_BUILD_GUIDE.md <<'MD'
# WORLD CONTROLLER Build Guide

## Purpose

WORLD CONTROLLER is the local-first, simulate-first command surface for Worldshepherd SARA / SSPADAWANZZ.

It adds:

- `/world/ui` browser console
- `/world/status`
- `/world/registry`
- `/world/command/parse`
- `/world/command/simulate`
- `/world/command/execute`
- `/world/audit`

## Safety model

Commands pass through:

```text
Command -> Guardian classification -> Oracle simulation -> Sentinel check -> Ark restore ID -> Audit record
```

Default execution rules:

- GREEN/BLUE can execute only with `execute_confirm=true`
- AMBER requires `WORLD_ALLOW_AMBER_EXECUTE=1` and confirmation
- RED/BLACK are denied by default
- No external side effects are performed in this first controller shell

## Install

Run from repo root:

```bash
./scripts/install_world_controller.sh ~/Sara_pro
cd ~/Sara_pro
python scripts/patch_world_controller_mount.py
python -m compileall worldshepherd_sara
```

Start the interface:

```bash
./scripts/start_interface.sh
```

Open:

```text
http://127.0.0.1:9530/world/ui
```

Smoke test:

```bash
./scripts/world_controller_smoke_test.sh
```

## Manual mount fallback

Find the file where your FastAPI app is created, then add:

```python
from worldshepherd_sara.world_controller import router as world_controller_router
app.include_router(world_controller_router)
```

Restart the service after editing.
MD

echo "WORLD CONTROLLER files installed into $ROOT"
echo "Next: python scripts/patch_world_controller_mount.py"
