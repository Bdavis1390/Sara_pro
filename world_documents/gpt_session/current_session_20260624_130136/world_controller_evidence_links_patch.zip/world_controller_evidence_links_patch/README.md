# WORLD CONTROLLER Evidence-Link Dossier Patch

Adds clickable evidence links inside the WORLD CONTROLLER Dossier UI.

## Adds

- `/world/evidence`
- `/world/evidence/node/{node_id}`
- `/world/evidence/registry/hash/{hash}`
- `/world/evidence/audit/{audit_id}`
- `/world/evidence/ark/{snapshot_id}`

## UI changes

- Evidence Index button
- Node evidence links
- Registry-hash evidence links
- Audit-record evidence links
- Ark restore-point evidence links
- Full-bloom human-readable evidence sections
- Raw evidence object toggle
- Raw JSON toggle

## Install

```bash
cd ~/Sara_pro
PKG="$(ls -t ~/Downloads/world_controller_evidence_links_patch*.zip | head -n1)"
rm -rf /tmp/world_controller_evidence_links_patch
mkdir -p /tmp/world_controller_evidence_links_patch
unzip -o "$PKG" -d /tmp/world_controller_evidence_links_patch >/dev/null
bash /tmp/world_controller_evidence_links_patch/world_controller_evidence_links_patch/scripts/install_world_controller_evidence_links.sh ~/Sara_pro
```

Then boot:

```bash
cd ~/Sara_pro && ./scripts/world_boot.sh
```

Smoke test:

```bash
cd ~/Sara_pro && ./scripts/world_controller_evidence_smoke_test.sh
```
