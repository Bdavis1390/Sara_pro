#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$HOME/Sara_pro}"
PKG_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ ! -d "$REPO" ]; then
  echo "[WORLD-EVIDENCE] ERROR: repo not found: $REPO" >&2
  exit 1
fi

mkdir -p "$REPO/worldshepherd_sara/world_controller_static"

if [ -f "$REPO/worldshepherd_sara/world_controller.py" ]; then
  cp "$REPO/worldshepherd_sara/world_controller.py" "$REPO/worldshepherd_sara/world_controller.py.bak_evidence_links_$(date +%s)"
fi
if [ -f "$REPO/worldshepherd_sara/world_controller_static/index.html" ]; then
  cp "$REPO/worldshepherd_sara/world_controller_static/index.html" "$REPO/worldshepherd_sara/world_controller_static/index.html.bak_evidence_links_$(date +%s)"
fi

cp "$PKG_ROOT/world_controller_files/world_controller.py" "$REPO/worldshepherd_sara/world_controller.py"
cp "$PKG_ROOT/world_controller_files/world_controller_static/index.html" "$REPO/worldshepherd_sara/world_controller_static/index.html"

cat > "$REPO/scripts/world_controller_evidence_smoke_test.sh" <<'SMOKE'
#!/usr/bin/env bash
set -euo pipefail
cd "${1:-$HOME/Sara_pro}"
ADMIN="$(grep '^SARA_ADMIN_TOKEN=' .env | cut -d= -f2-)"
BASE="http://127.0.0.1:9530"
H=(-H "X-SARA-ADMIN-TOKEN: $ADMIN")

json_get() {
  local label="$1"
  local path="$2"
  echo "$label"
  curl -fsS "${H[@]}" "$BASE$path" | python3 -m json.tool >/tmp/world_evidence_test.json
  python3 - <<'PY'
import json
p='/tmp/world_evidence_test.json'
data=json.load(open(p))
assert data.get('ok') is not False, data
print('  ok:', data.get('panel') or data.get('service') or data.get('title'))
PY
}

json_get "[1] Evidence index" "/world/evidence"
json_get "[2] Registry dossier" "/world/registry"
HASH="$(curl -fsS "${H[@]}" "$BASE/world/registry" | python3 -c 'import sys,json; print(json.load(sys.stdin)["registry_hash"])')"
json_get "[3] Registry hash evidence" "/world/evidence/registry/hash/$HASH"
json_get "[4] Node evidence" "/world/evidence/node/SARA_CORE"
SNAP="$(curl -fsS -X POST "${H[@]}" "$BASE/world/ark/snapshot" | python3 -c 'import sys,json; print(json.load(sys.stdin)["snapshot_id"])')"
json_get "[5] Ark evidence" "/world/evidence/ark/$SNAP"
AUD="$(curl -fsS "${H[@]}" "$BASE/world/audit?limit=10" | python3 -c 'import sys,json; rows=json.load(sys.stdin).get("records",[]); print(rows[0]["audit_id"] if rows else "")')"
if [ -n "$AUD" ]; then
  json_get "[6] Audit evidence" "/world/evidence/audit/$AUD"
fi

echo "WORLD CONTROLLER evidence-link dossier smoke test passed"
SMOKE
chmod +x "$REPO/scripts/world_controller_evidence_smoke_test.sh"

cat > "$REPO/scripts/world_boot.sh" <<'BOOT'
#!/usr/bin/env bash
set -euo pipefail

REPO="${1:-$HOME/Sara_pro}"
EVIDENCE_ZIP="$(ls -t "$HOME"/Downloads/world_controller_evidence_links_patch*.zip 2>/dev/null | head -n1 || true)"
DOSSIER_ZIP="$(ls -t "$HOME"/Downloads/world_controller_dossier_ui_patch*.zip 2>/dev/null | head -n1 || true)"
FULL_ZIP="$(ls -t "$HOME"/Downloads/world_controller_full_controls_patch*.zip 2>/dev/null | head -n1 || true)"
BASE_ZIP="$(ls -t "$HOME"/Downloads/world_controller_build_package*.zip 2>/dev/null | head -n1 || true)"

echo "[WORLD] Repo: $REPO"
cd "$REPO"

install_zip_script() {
  local zip="$1" dest="$2" script_rel="$3" label="$4"
  echo "[WORLD] Installing $label from: $zip"
  rm -rf "$dest"
  mkdir -p "$dest"
  unzip -o "$zip" -d "$dest" >/dev/null
  bash "$dest/$script_rel" "$REPO"
}

if [ -n "$EVIDENCE_ZIP" ]; then
  install_zip_script "$EVIDENCE_ZIP" /tmp/world_controller_evidence_links_patch "world_controller_evidence_links_patch/scripts/install_world_controller_evidence_links.sh" "EVIDENCE-LINK DOSSIER CONTROLS"
elif grep -q '/evidence/node/{node_id}' "$REPO/worldshepherd_sara/world_controller.py" 2>/dev/null; then
  echo "[WORLD] Evidence-link dossier controls already present."
elif [ -n "$DOSSIER_ZIP" ]; then
  install_zip_script "$DOSSIER_ZIP" /tmp/world_controller_dossier_ui_patch "world_controller_dossier_ui_patch/scripts/install_world_controller_dossier_ui.sh" "DOSSIER UI"
elif [ -n "$FULL_ZIP" ]; then
  install_zip_script "$FULL_ZIP" /tmp/world_controller_full_controls_patch "world_controller_full_controls_patch/scripts/install_world_controller_full_controls.sh" "FULL CONTROLS"
elif [ -n "$BASE_ZIP" ]; then
  install_zip_script "$BASE_ZIP" /tmp/world_controller_build "world_controller_build_package/scripts/install_world_controller.sh" "BASE CONTROLS"
else
  echo "[WORLD] WARNING: no WORLD CONTROLLER package zip found in ~/Downloads. Continuing with repo files."
fi

if [ ! -f "$REPO/.env" ] && [ -f "$REPO/.env.example" ]; then
  cp "$REPO/.env.example" "$REPO/.env"
elif [ ! -f "$REPO/.env" ]; then
  touch "$REPO/.env"
fi
if ! grep -q '^SARA_ADMIN_TOKEN=' "$REPO/.env"; then
  echo "SARA_ADMIN_TOKEN=change-me-admin-token" >> "$REPO/.env"
fi

echo "[WORLD] Verifying evidence-link routes..."
grep -q '/evidence/node/{node_id}' "$REPO/worldshepherd_sara/world_controller.py" || {
  echo "[WORLD] ERROR: evidence-link routes missing. Make sure world_controller_evidence_links_patch.zip is in ~/Downloads."
  exit 1
}

echo "[WORLD] Compiling Python..."
python3 -m compileall worldshepherd_sara >/dev/null

echo
echo "[WORLD] Boot targets:"
echo "  Legacy UI: http://127.0.0.1:9530/ui"
echo "  WORLD UI:  http://127.0.0.1:9530/world/ui"
echo

if [ -x "$REPO/scripts/start_interface.sh" ]; then
  exec "$REPO/scripts/start_interface.sh"
else
  echo "[WORLD] ERROR: scripts/start_interface.sh not found or not executable."
  exit 1
fi
BOOT
chmod +x "$REPO/scripts/world_boot.sh"

python3 -m compileall "$REPO/worldshepherd_sara" >/dev/null || true

echo "[WORLD-EVIDENCE] Evidence-link dossier controls installed into $REPO"
echo "[WORLD-EVIDENCE] Routes added: /world/evidence, /world/evidence/node/{node_id}, /world/evidence/audit/{audit_id}, /world/evidence/ark/{snapshot_id}, /world/evidence/registry/hash/{hash}"
echo "[WORLD-EVIDENCE] Next: cd $REPO && ./scripts/world_boot.sh"
